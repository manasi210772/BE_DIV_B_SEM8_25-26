from flask import Flask, render_template, request
import pandas as pd
import numpy as np
from textblob import TextBlob
import yfinance as yf
import warnings

warnings.filterwarnings('ignore')

app = Flask(__name__)

# Stock Dataset
stock_data = {
    "Stock": [
        "TCS", "Zomato", "HDFC", "Tata Motors", "Infosys", "Paytm",
        "HDFC Mutual Fund", "SBI SIP", "Apollo Hospital", "ICICI Prudential MF",
        "Max Healthcare", "Gold", "Silver", "Bitcoin (Crypto)",
        "EUR/USD (Forex)", "USD/INR (Currency)", "Reliance (Oil & Gas)",
        "Nifty Futures (F&O)", "TCS (Intraday)", "Infosys (Swing)",
        "Adani Power", "Maruti Suzuki", "Asian Paints", "Coal India", "Hindustan Unilever"
    ],
    "Sector": [
        "IT", "Startup", "Banking", "Auto", "IT", "Fintech",
        "Mutual Fund", "SIP", "Hospital", "Mutual Fund",
        "Hospital", "Commodities", "Commodities", "Crypto",
        "Forex", "Currency", "Oil & Gas", "F&O", "Intraday", "Swing",
        "Energy", "Auto", "Paints", "Commodities", "FMCG"
    ],
    "Risk_Level": [
        "Low", "High", "Medium", "High", "Low", "High",
        "Low", "Low", "Low", "Low",
        "Medium", "Low", "Low", "High",
        "Medium", "High", "Very High", "High", "High", "Medium",
        "High", "Medium", "Low", "Medium", "Low"
    ],
    "Avg_Annual_Return": [
        10, 22, 12, 18, 11, 20,
        8, 9, 7, 8, 6, 6, 7, 25, 5, 4, 15, 25, 30, 35, 20, 18, 10, 14, 9
    ],
    "Min_Investment": [
        5000, 1000, 10000, 2000, 3000, 1000,
        500, 500, 1000, 500,
        1000, 1000, 1000, 100, 100,
        2000, 1000, 500, 1000, 200,
        2000, 3000, 500, 1000, 2000
    ],
    "Max_Investment": [
        200000, 30000, 100000, 100000, 150000, 50000,
        100000, 50000, 50000, 100000,
        50000, 200000, 200000, 100000, 500000,
        500000, 200000, 50000, 50000, 50000,
        200000, 100000, 100000, 100000, 200000
    ],
    "Market_Type": [
        "Markets", "Markets", "Finance", "Markets", "Tech", "Finance",
        "Mutual Funds", "SIP", "Medical", "Mutual Funds",
        "Medical", "Commodities", "Commodities", "Crypto",
        "Forex", "Currency", "Oil and Gas", "F&O", "Intraday", "Swing trade",
        "Energy", "Markets", "Paints", "Commodities", "FMCG"
    ]
}

stock_df = pd.DataFrame(stock_data)
MARKET_TYPES = sorted(stock_df["Market_Type"].unique())

# Symbol mapping for Yahoo Finance
SYMBOL_MAP = {
    "TCS": "TCS.NS",
    "Infosys": "INFY.NS",
    "HDFC": "HDFCBANK.NS",
    "Tata Motors": "TATAMOTORS.NS",
    "Zomato": "ZOMATO.NS",
    "Paytm": "PAYTM.NS",
    "Reliance (Oil & Gas)": "RELIANCE.NS",
    "Adani Power": "ADANIPOWER.NS",
    "Maruti Suzuki": "MARUTI.NS",
    "Asian Paints": "ASIANPAINT.NS",
    "Coal India": "COALINDIA.NS",
    "Hindustan Unilever": "HINDUNILVR.NS",
    "Apollo Hospital": "APOLLOHOSP.NS",
    "Max Healthcare": "MAXHEALTH.NS",
    "Gold": "GC=F",
    "Silver": "SI=F",
    "Bitcoin (Crypto)": "BTC-USD"
}


def get_sentiment_score(stock_name):
    """Get text-based sentiment score using TextBlob"""
    headlines = [
        f"{stock_name} shows strong quarterly performance",
        f"Analysts bullish on {stock_name} outlook",
        f"{stock_name} announces strategic expansion",
        f"Market volatility affects {stock_name}",
        f"{stock_name} maintains steady growth"
    ]
    
    sentiments = [TextBlob(h).sentiment.polarity for h in headlines]
    avg_sentiment = np.mean(sentiments)
    return (avg_sentiment + 1) / 2


def get_market_sentiment(stock_name):
    """Get real market data and calculate sentiment"""
    symbol = SYMBOL_MAP.get(stock_name)
    
    default_response = {
        'sentiment_score': 0.5,
        'price_momentum': 0.0,
        'volume_trend': 0.0,
        'analyst_sentiment': 0.5,
        'recommendation': 'HOLD ⏸️'
    }
    
    if not symbol:
        return default_response
    
    try:
        ticker = yf.Ticker(symbol)
        hist = ticker.history(period="1mo")
        
        if hist.empty or len(hist) < 5:
            return default_response
        
        # Price momentum
        recent_prices = hist['Close'].tail(5)
        price_change = (recent_prices.iloc[-1] - recent_prices.iloc[0]) / recent_prices.iloc[0]
        price_momentum = np.tanh(price_change * 10)
        
        # Volume trend
        avg_volume = hist['Volume'].mean()
        recent_volume = hist['Volume'].tail(3).mean()
        volume_trend = (recent_volume - avg_volume) / avg_volume if avg_volume > 0 else 0
        volume_trend = np.tanh(volume_trend)
        
        # Analyst recommendation
        try:
            info = ticker.info
            rec_key = info.get('recommendationKey', 'hold')
            rec_map = {'strong_buy': 1.0, 'buy': 0.75, 'hold': 0.5, 'sell': 0.25, 'strong_sell': 0.0}
            analyst_sentiment = rec_map.get(rec_key.lower(), 0.5)
        except:
            analyst_sentiment = 0.5
        
        # Combined sentiment
        sentiment_score = (
            0.4 * ((price_momentum + 1) / 2) +
            0.3 * ((volume_trend + 1) / 2) +
            0.3 * analyst_sentiment
        )
        
        # Generate recommendation
        if sentiment_score > 0.7:
            recommendation = 'STRONG BUY 🚀'
        elif sentiment_score > 0.6:
            recommendation = 'BUY 📈'
        elif sentiment_score > 0.4:
            recommendation = 'HOLD ⏸️'
        elif sentiment_score > 0.3:
            recommendation = 'WATCH 👁️'
        else:
            recommendation = 'AVOID ⚠️'
        
        return {
            'sentiment_score': sentiment_score,
            'price_momentum': price_momentum,
            'volume_trend': volume_trend,
            'analyst_sentiment': analyst_sentiment,
            'recommendation': recommendation
        }
        
    except Exception as e:
        print(f"Error fetching market data for {stock_name}: {e}")
        return default_response


def calculate_sentiment_adjusted_score(row, base_score):
    """Adjust base score with sentiment analysis"""
    stock_name = row['Stock']
    
    # Get sentiments
    text_sentiment = get_sentiment_score(stock_name)
    market_data = get_market_sentiment(stock_name)
    market_sentiment = market_data['sentiment_score']
    
    # Combined sentiment (60% market, 40% text)
    combined_sentiment = 0.6 * market_sentiment + 0.4 * text_sentiment
    
    # Adjust base score (sentiment can boost/reduce by up to 20%)
    sentiment_adjustment = (combined_sentiment - 0.5) * 0.4
    adjusted_score = base_score * (1 + sentiment_adjustment)
    
    return adjusted_score, combined_sentiment, market_data


def get_sentiment_label(sentiment_score):
    """Convert sentiment score to label"""
    if sentiment_score > 0.7:
        return "Very Bullish"
    elif sentiment_score > 0.6:
        return "Bullish"
    elif sentiment_score > 0.4:
        return "Neutral"
    elif sentiment_score > 0.3:
        return "Bearish"
    else:
        return "Very Bearish"


@app.route("/", methods=["GET", "POST"])
def index():
    recommendations = None
    error = None
    selected_types = []
    age_value = ""
    invest_value = ""
    sentiment_enabled = False

    if request.method == "POST":
        age_str = request.form.get("age", "").strip()
        invest_str = request.form.get("investment", "").strip()
        selected_types = request.form.getlist("market_types")
        sentiment_enabled = request.form.get("enable_sentiment") == "on"
        
        age_value = age_str
        invest_value = invest_str

        if not age_str or not invest_str:
            error = "Please enter both age and investment amount."
        else:
            try:
                user_age = int(age_str)
                user_investment = int(invest_str)
            except ValueError:
                error = "Age and investment must be numeric values."
            else:
                try:
                    # Filtering logic
                    if user_age < 25 and user_investment < 10000:
                        filtered = stock_df[
                            (stock_df["Risk_Level"].isin(["Low", "Medium"])) &
                            (stock_df["Min_Investment"] <= user_investment)
                        ].copy()
                        filtered = filtered[filtered["Market_Type"].isin(["Commodities", "Mutual Funds", "SIP"])]
                        filtered = filtered.nsmallest(8, "Min_Investment")

                    elif user_age >= 25 and user_investment >= 10000:
                        filtered = stock_df[
                            (stock_df["Min_Investment"] <= user_investment) &
                            (stock_df["Max_Investment"] >= user_investment)
                        ].copy()
                        priority = stock_df[stock_df["Stock"].isin([
                            "Gold", "Silver", "HDFC Mutual Fund", "ICICI Prudential MF"
                        ])]
                        filtered = pd.concat([filtered, priority]).drop_duplicates(subset=["Stock"])
                    else:
                        filtered = stock_df[stock_df["Min_Investment"] <= user_investment].copy()

                    # Market type filtering
                    if selected_types:
                        filtered = filtered[filtered["Market_Type"].isin(selected_types)].copy()
                        num_selected = len(selected_types)
                        limit = 5 if num_selected == 1 else (10 if num_selected <= 3 else 15)
                    else:
                        limit = 10

                    # Guarantee at least 5 recommendations
                    if len(filtered) < 5:
                        extras = stock_df.sample(min(5 - len(filtered), len(stock_df)))
                        filtered = pd.concat([filtered, extras]).drop_duplicates(subset=["Stock"])

                    # Calculate base scores
                    risk_map = {"Low": 0.1, "Medium": 0.5, "High": 0.9, "Very High": 0.95}
                    filtered["Risk_Score"] = filtered["Risk_Level"].map(risk_map)
                    filtered["Return_Score"] = filtered["Avg_Annual_Return"] / filtered["Avg_Annual_Return"].max()
                    filtered["Hybrid_Score"] = 0.6 * filtered["Return_Score"] + 0.4 * (1 - filtered["Risk_Score"])
                    filtered["Return_Rupees"] = (filtered["Avg_Annual_Return"] / 100) * user_investment

                    # Sentiment integration
                    if sentiment_enabled:
                        for idx, row in filtered.iterrows():
                            adjusted_score, combined_sentiment, market_data = calculate_sentiment_adjusted_score(
                                row, row["Hybrid_Score"]
                            )
                            
                            filtered.at[idx, "Final_Score"] = adjusted_score
                            filtered.at[idx, "Sentiment_Score"] = combined_sentiment
                            filtered.at[idx, "Sentiment_Label"] = get_sentiment_label(combined_sentiment)
                            filtered.at[idx, "Recommendation"] = market_data['recommendation']
                            filtered.at[idx, "Price_Momentum"] = f"{market_data['price_momentum']:.2f}"
                        
                        sort_column = "Final_Score"
                    else:
                        filtered["Final_Score"] = filtered["Hybrid_Score"]
                        sort_column = "Final_Score"

                    # Final sorting and limiting
                    if not filtered.empty:
                        recommendations = filtered.sort_values(
                            by=sort_column, ascending=False
                        ).head(limit)
                    else:
                        error = "No suitable stocks found for your criteria."

                except Exception as e:
                    error = f"Error: {str(e)}"

    return render_template(
        "index.html",
        recommendations=recommendations,
        error=error,
        market_types=MARKET_TYPES,
        selected_types=selected_types,
        age_value=age_value,
        invest_value=invest_value,
        sentiment_enabled=sentiment_enabled
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)